
package controller.tab;

import controller.MainController;
import java.io.File;
import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Tab4Controller {
    
     private MainController main;
     @FXML public MenuItem menufileopen;
     
     @FXML
     public List<File> fileList;
    
    
    public void init(MainController mainController) {
		main = mainController;
	}
    
    /// Action listner for MENU BUTTONS/////////
    
    @FXML private void menuFileOpen(ActionEvent event) throws IOException{
        System.out.println("file open clicked");
       // fileList.clear();
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open File");
        fileList = chooser.showOpenMultipleDialog(new Stage());
                 if( fileList != null ){
                   if( !fileList.isEmpty() ){
                       System.out.println(fileList.get(0).getPath());
                       main.setFilePath(fileList);
                   }


                   
               }
        
    }
}
