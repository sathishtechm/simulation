/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tab;

import controller.MainController;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;

/**
 *
 * @author SB00519010
 */
public class Tab5Controller {
     private MainController main;
     @FXML public TextArea selectedfrmeq ;
    
     public void setselectedfrmeq(String frmeq){             
         
         selectedfrmeq.setText(frmeq);
          }
     
    
    public void init(MainController mainController) {
		main = mainController;
	}
}
