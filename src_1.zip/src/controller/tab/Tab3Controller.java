/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tab;

import controller.MainController;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import javafx.scene.control.ComboBox;



/**
 *
 * @author SB00519010
 */
public class Tab3Controller {
    
    private MainController main;
    
    @FXML
    private ComboBox icmcombo;
    @FXML
    public List<String> scmfulleq=new ArrayList<String>();
    @FXML
    public List<String> scmlefteq=new ArrayList<String>();
    @FXML
    public List<String> scmrighteq=new ArrayList<String>();
    @FXML
    public List<String> icmfulleq=new ArrayList<String>();
    @FXML
    public List<String> icmlefteq=new ArrayList<String>();
    @FXML
    public List<String> icmrighteq=new ArrayList<String>();
    @FXML
    public List<String> frmfulleq=new ArrayList<String>();
    @FXML
    public List<String> frmlefteq=new ArrayList<String>();
    @FXML
    public List<String> frmrighteq=new ArrayList<String>();
    @FXML
     public List<String> dynvaluefulleq=new ArrayList<String>();
   @FXML
  public  ArrayList<String> numberofASXL = new ArrayList<String>();
    @FXML
  public  ArrayList<String> totalnumberofASXL = new ArrayList<String>();
   @FXML
  public  ArrayList<String> numberofTP53 = new ArrayList<String>();
      @FXML
  public  ArrayList<String> totalnumberofTP53 = new ArrayList<String>();
    @FXML
  public  ArrayList<String> numberofKRAS = new ArrayList<String>();
     @FXML
  public  ArrayList<String> totalnumberofKRAS = new ArrayList<String>();
     @FXML
  public  ArrayList<String> allgenevalues = new ArrayList<String>();
      @FXML
  public  ArrayList<String> allgenevalues2 = new ArrayList<String>();
     @FXML
  public  ArrayList<String> allRkvalues = new ArrayList<String>();
     @FXML
     public ArrayList<String> allRkvaluesfulleq= new ArrayList<String>();
     @FXML
     public ArrayList<String> totalRk = new ArrayList<String>();
     
    @FXML
    private ComboBox scmcombo;
    @FXML
    private ComboBox frmcombo;
     @FXML
    private ComboBox genecombo;
     @FXML
    private ComboBox genecombo2;
    @FXML
    private String fname;
    @FXML 
    public String path;
    @FXML 
    public String dynpath;
    @FXML
    public  ArrayList<String> regCon = new ArrayList<String>();
    @FXML
    List<String> paths = new ArrayList<String>();
    @FXML
     List<String>  allscmslectedvalues =new ArrayList<String>(); 
    @FXML
     List<String>  allicmslectedvalues =new ArrayList<String>(); 
    @FXML
    public  Set<Integer> set = new HashSet<Integer>();
    @FXML
    public Set<String> Rkset = new HashSet<String>();
    @FXML
    public Set<String> allRkset = new HashSet<String>();
    public HashMap<String,String> species=new HashMap<String,String>();  
    public HashMap<String,String> reaction=new HashMap<String,String>();  
    public HashMap<String,String> parameters=new HashMap<String,String>();  
     //public HashMap<String, String> newMap = new HashMap<String, String>();

    @FXML
     List<String>  speciesvalues=new ArrayList<String>(); 
    @FXML
     List<String>  reactionvalues =new ArrayList<String>(); 
    @FXML
     List<String>  parametervalues =new ArrayList<String>(); 
    @FXML
     List<String>  MDSL=new ArrayList<String>(); 
    
    
   public String mdslpath ;
    
    
      public void getFilePath(List<File> file)
   {
      
      // System.out.println(file.get(0).getPath());
    
     for(int i=0;i<file.size();i++){
         //System.out.println(file.get(i).getPath());
       paths.add(file.get(i).getPath());
   }
       comboSelections();
   }
      
     
    
    private void comboSelections(){
        for(int i =0;i<paths.size();i++){
       String line;
      
                         try
	                    {BufferedReader reader = new BufferedReader(new FileReader(paths.get(i)));
                            File f = new File(paths.get(i));
                           // System.out.println(f.getName());
                            //System.out.println(paths.get(0).lastIndexOf("\\")+1);
	                    while ((line = reader.readLine()) != null)
	                    {
                                line= line.replaceAll("	","").replaceAll(" ","").replaceAll(";", "");
                                //System.out.println(line);
	                        String[] parts = line.split("=", 2);
	                        if (parts.length >= 2)
	                        {
	                            String key = parts[0];
	                            String value = parts[1];
                                    
                                    if(f.getName().contains("icm"))
                                    {
                                         icmcombo.getItems().add(key);
                                         icmfulleq.add(line);
                                         icmlefteq.add(key);
                                         icmrighteq.add(value);
                                        // icmcombo.setVisible(true);
                                    }
                                    else if(f.getName().contains("init")){
                                            scmcombo.getItems().add(key);
                                            scmfulleq.add(line);
                                            scmlefteq.add(key);
                                            scmrighteq.add(value);
                                          //  scmcombo.setVisible(true);
                                            }
                                    else if(f.getName().contains("frm")){
                                            fname=paths.get(i);
                                            frmcombo.getItems().add(key);
                                            frmfulleq.add(line);
                                            frmlefteq.add(key);
                                            
                                            frmrighteq.add(value);
                                            //frmcombo.setVisible(true);
                                            }
                                     //else if(f.getName().contains("dyn")){
                                        //  dynvaluefulleq.add(line);
                                        //  }
                                }
	                            
	                         
	                       
	                    } }
                         
                         
                         catch(IOException s){ 
	                        //System.out.println("Error, could not read file"); 

	                    }
                         
        }
        getASXL();
       // getTP53();
        //getKRAS();
    String line2;
                         
                          for(int j =0; j<paths.size(); j++){
                          try
	                    {
                                BufferedReader reader = new BufferedReader(new FileReader(paths.get(j)));
                            
                            File f = new File(paths.get(j));
                            if(f.getName().contains("dyn")){
                                 dynpath=paths.get(j);
                                // System.out.println("pathof dyn file"+dynpath);
                                 main.setdynpath(dynpath);
                         while ((line2 = reader.readLine()) != null)
	                    {
                                //line2= line2.replaceAll("[","").replaceAll("]","");
                                
                                    //dynvaluefulleq.clear();
                                          dynvaluefulleq.add(line2);
                                          //System.out.println("LINES2::"+dynvaluefulleq );
                                          
                                           
                                          
                                
                            }}
                            
                            
                            if(f.getName().contains("Reaction_Name")){
                                
                                    String read;
                                 while ((read = reader.readLine()) != null)
	                    {
                              String[] out = read.split(",");   
                              reaction.put(out[1], out[0]);
                            }
                            }
                            
                            
                            if(f.getName().contains("Species")){
                                
                                //System.out.println("excel file updated");
                                 String read;
                                 while ((read = reader.readLine()) != null)
	                    {
                              String[] out = read.split(",");   
                              species.put(out[1], out[0]);
                            }
                         }
                            
                            
                            if(f.getName().contains("Parameter_Name")){
                               
                                  String read;
                                 while ((read = reader.readLine()) != null)
	                    {
                              String[] out = read.split(",");   
                              parameters.put(out[1], out[0]);
                            }
                              
                            }
                            
                            
                            if(f.getName().contains("MDSL")){
                                System.out.println("adskfh path   "+f.getParent());
                                mdslpath=f.getParent();
                                //System.out.println("excel file updated");
                                String read;
                                while ((read = reader.readLine()) != null)
	                    {
                                
                                 Pattern p1 = Pattern.compile("knockover");
                                 Matcher m1 = p1.matcher(read);
                                    if (m1.find()) {  
                                     MDSL.add(read);
                                   //  System.out.println("reading successfullu");
                                                   } 
                            }
                                
                            }
                            
                            
                         }
                           catch(IOException e){ 
	                        //System.out.println("Error, could not read file"); 

	                    }
                          }
                          
                        if(MDSL.size()!=0){
                                    
                                // System.out.println("readsfhah");
                                 MDSL();
                                }
                          
                          
                          
                          if(dynvaluefulleq.size()==0){
                              
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Upload DYNAMIC VALUE FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();
                          }
    
        for(int x=0;x<frmfulleq.size();x++){
             Pattern p1 = Pattern.compile(" 	//g");
            //System.out.println(x);
        //String xs=;
   	     Matcher m1 = p1.matcher(frmfulleq.get(x));
        if (m1.find()) {  
             frmfulleq.remove(x);
           // System.out.println(x);
                       }      
        }
         //System.out.println(path);
        for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("Rk");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
        if (m1.find()) {  
            regCon.add(x);
           // System.out.println(x);
                       }      
            }
        for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("Rk\\w+mut");
            Pattern p3 = Pattern.compile("Rk\\w+mut");
            Pattern p2 = Pattern.compile("Rk_1_\\w+mut");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
             Matcher m3 = p3.matcher(x);
        while (m1.find()) {  
            allRkset.add(m1.group());
            
            //System.out.println("check"+m1.group());
           
            
            }   
        if(m3.find()) {
            allRkvaluesfulleq.add(x);
            //System.out.println(x);
            }   
        
       
         
            Matcher m2 = p2.matcher(x);
        while (m2.find())
        {
            String rk[]= m2.group().split("_");
            //System.out.println("split string"+rk[2]);
            //System.out.println("values of 1"+m2.group());
            Rkset.add(rk[2]);
        }
            }
        
        genecombo2.getItems().addAll(Rkset);
        genecombo2.setVisible(true);
        
        
        
          for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("ASXL");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
        if (m1.find()) {  
           totalnumberofASXL.add(x);
           // System.out.println(x);
                       }      
            }
            for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("TP53");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
        if (m1.find()) {  
            totalnumberofTP53.add(x);
           // System.out.println(x);
                       }      
            }
            for(String x :frmfulleq){
            Pattern p1 = Pattern.compile("KRAS");
            //System.out.println(x);
        
   	     Matcher m1 = p1.matcher(x);
        if (m1.find()) {  
            totalnumberofKRAS.add(x);
           // System.out.println(x);
                       }      
            }
       // for(String z :dynvaluefulleq){
          //  dynvaluefulleq2.add(z);
          //  System.out.println("LINES2::"+dynvaluefulleq2);
        //}
             main.setAllDynValues(dynvaluefulleq);
    }
   
      public void MDSL(){
          
          for(String x: MDSL){
              
              String[] out = x.split(" ");
              String type=out[1];
              if(out[1].equals("-k")){
              float lastvalue=((100-Float.parseFloat(out[4]))/100);
                if(out[2].equals("-s")){
                String value = species.get(out[3]);
                String svalue=value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                speciesvalues.add(svalue);
                }
                else if(out[2].equals("-r")){
                String value = reaction.get(out[3]);
                String svalue= value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                reactionvalues.add(svalue);
                }
                else if(out[2].equals("-p")){
                String value = parameters.get(out[3]);
                String svalue= value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                parametervalues.add(svalue);
                }
             // System.out.println("ovalue"+lastvalue);
              }
              else
              {
              float lastvalue = ((100+Float.parseFloat(out[4]))/100);
              if(out[2].equals("-s")){
                String value = species.get(out[3]);
                String svalue= value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                speciesvalues.add(svalue);
                }
                else if(out[2].equals("-r")){
                String value = reaction.get(out[3]);
                String svalue= value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                reactionvalues.add(svalue);
                }
                else if(out[2].equals("-p")){
                String value = parameters.get(out[3]);
                String svalue= value+" = "+value+"*"+lastvalue;
                //System.out.println("species name"+svalue);
                parametervalues.add(svalue);
                }
              //System.out.println("kvalue"+lastvalue);
              }
              
              //System.out.println(out[out.length-1]);
          }
          
          main.setMDSL(speciesvalues,reactionvalues,parametervalues,mdslpath);
      }
    
    
    
    private void getASXL(){

       // System.out.println("checking"+frmfulleq.get(0));
        for(String y :frmfulleq){        

               Pattern p2 = Pattern.compile("ASXL(\\d+)");
               
               Matcher m2 = p2.matcher(y);
               while (m2.find()) {  
            //regCon.add(x);
                   numberofASXL.add(m2.group());
                   //System.out.println(y);   
    } }
for(int i=0;i<numberofASXL.size();i++){
String con=numberofASXL.get(i).replaceAll("ASXL", "");
    //System.out.println(con);

set.add(Integer.valueOf(con));
    }
for(int x:set){
    //System.out.println("xvalues"+x);
    genecombo.getItems().add("ASXL"+x);
    genecombo.getItems().add("TP53");
     genecombo.getItems().add("KRAS");
    //genecombo.setVisible(true);
}

    }
    
       @FXML private void ongeneselect(ActionEvent event) {
    
           
           String geneselectedvalue=genecombo.getSelectionModel().getSelectedItem().toString();
    if(frmfulleq.isEmpty())
        
            {
            //System.out.println("please upload file");
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Upload FRM FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();   }
    
    else{
        allgenevalues.clear();
        if(geneselectedvalue.contains("ASXL")){
        
        for(String y :totalnumberofASXL){        
          
               Pattern p2 = Pattern.compile(geneselectedvalue);
               
               Matcher m2 = p2.matcher(y);
                if (m2.find()) {  
            //regCon.add(x);
           //  System.out.println(y);
             allgenevalues.add(y);
           
           //System.out.println(x);
                       }                   
                
            }
        main.getAllGeneValues(allgenevalues,"ASXL");
    }
        else if(geneselectedvalue.contains("TP53")){
        
        for(String y :totalnumberofTP53){        
          
               Pattern p2 = Pattern.compile(geneselectedvalue);
               
               Matcher m2 = p2.matcher(y);
                if (m2.find()) {  
            //regCon.add(x);
           //  System.out.println(y);
             allgenevalues.add(y);
           
           //System.out.println(x);
                       }                   
                
            }
        main.getAllGeneValues(allgenevalues,"TP53");
    }
        
        else if(geneselectedvalue.contains("KRAS")){
        
        for(String y :totalnumberofKRAS){        
          
               Pattern p2 = Pattern.compile(geneselectedvalue);
               
               Matcher m2 = p2.matcher(y);
               ArrayList<String> use = new ArrayList<String>();
                if (m2.find()) {  
                    
                    
            //regCon.add(x);
           //  System.out.println(y);
             allgenevalues.add(y);
           
           //System.out.println(x);
                       }                   
                
            }
         main.getAllGeneValues(allgenevalues,"KRAS");
    }
    
      
    
    }

       }
       
       
        @FXML private void ongeneselect2(ActionEvent event) {
            
        String geneselectedvalue=genecombo2.getSelectionModel().getSelectedItem().toString();
        allgenevalues2.clear();
        ArrayList<String> rkselectedvaues = new ArrayList<String>();
        ArrayList<String> filter =new ArrayList<String>();
        for(String y :allRkset){        
          
               Pattern p2 = Pattern.compile(geneselectedvalue);
               Matcher m2 = p2.matcher(y);
             
                while(m2.find()) {
                filter.add(y);
                       }
            }
        for(String y:filter){
           // System.out.println("hdsf"+y);
            for(String x :allRkvaluesfulleq){        
          
               Pattern p2 = Pattern.compile(y);
               Matcher m2 = p2.matcher(x);
             
                if(m2.find()) {
                rkselectedvaues.add(x);
                break;
                       }
            }
            
        }
        main.getAllGeneValues2(rkselectedvaues,geneselectedvalue);
       
            
        }
       
       
       
       
       
       
    @FXML private void onScmComboSelect(ActionEvent event) {
        
       // System.out.println(scmcombo.getSelectionModel().getSelectedItem());
        
        String scmselectedvalue=scmcombo.getSelectionModel().getSelectedItem().toString();
      //  if(frmfulleq.size()!=0){
        
            if(frmfulleq.isEmpty())
            {
          //  System.out.println("please upload file");
            
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Upload FRM FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();

            
        }
        else
        {
         
            scmselectedvalue=scmselectedvalue.replace("[", "\\[").replace("]", "\\]");
            allscmslectedvalues.clear();
           
           for(String y :regCon){        
          
               Pattern p2 = Pattern.compile(scmselectedvalue+"\\*Rk");
               
               Matcher m2 = p2.matcher(y);
                if (m2.find()) {  
            //regCon.add(x);
           //  System.out.println(y);
             allscmslectedvalues.add(y);
           
           //System.out.println(x);
                       }                   
                
            }
           if(allscmslectedvalues.isEmpty())
           {
               allscmslectedvalues.add("no values detected");
           }
               
                main.getAllScmSelectedValues(allscmslectedvalues);
               
                 
           }
    
        
    }
        
        
    
    
    @FXML private void onIcmComboSelect(ActionEvent event) {
        
        //System.out.println(icmcombo.getSelectionModel().getSelectedItem());
        //allicmslectedvalues.add((String) icmcombo.getSelectionModel().getSelectedItem());

        if(allicmslectedvalues.isEmpty())
           {
               allicmslectedvalues.add("no values detected");
           }
               
                main.getAllIcmSelectedValues(allicmslectedvalues); 
        
        
     
        
    }
    
     @FXML private void onFrmComboSelect(ActionEvent event) {
        
    }
    
    
    public void init(MainController mainController) {
		main = mainController;
                
	}

    
    
    
}
