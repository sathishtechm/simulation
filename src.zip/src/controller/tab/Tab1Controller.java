package controller.tab;


import controller.MainController;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import jdk.nashorn.internal.ir.Labels;

public class Tab1Controller {
	
	private MainController main;
    @FXML public TextArea regtextarea;
    @FXML public Rectangle regrect;
    @FXML public Label reglabel;  
    @FXML public Pane content = new Pane();
    @FXML public ScrollPane content2 ;
    @FXML private Line regline;
     @FXML private Line regline2;
    @FXML private Label nodata =new Label();
    @FXML
     private GridPane gridPane ;
    @FXML public String buttonaxis;
    @FXML
    private Label regchildlabel ;
    @FXML
    private Label regchildlabel2 ;
    @FXML
    private final Button regeditBtn =new Button("Edit");
    @FXML
    private final Button regsubmitBtn =new Button("Submit");
     @FXML
    private TextArea regchildtext ;
    @FXML
    private Labels Labe ;
     @FXML 
    public String dynpath;
    @FXML
    public List<String> fetchedscmvalues = new ArrayList<String>();
     @FXML
    public List<String> fetchedgenevalues = new ArrayList<String>();
     @FXML
    public List<String> fetchedgenevalues2 = new ArrayList<String>();
    @FXML
    public List<TextArea> regtextareacollections = new ArrayList<TextArea>();
    @FXML
    public List<TextArea> regtextareacollections2 = new ArrayList<TextArea>();
    @FXML
    public List<TextArea> regtextareacollectionseditvalues = new ArrayList<TextArea>();
    @FXML
     public List<String> dynvaluefulleq2=new ArrayList<String>();
    @FXML
     public List<String> dynvaluefulleq3=new ArrayList<String>();
    @FXML
     public List<String> gettextareavalue=new ArrayList<String>();
   
    @FXML
    public String selectedtype;
	public void getAllScmSelectedValues(List <String> scmrk){       
           
            fetchedscmvalues.clear(); 
           System.out.println("\n");
          // System.out.println("0th value:"+scmrk.get((0)));
           fetchedscmvalues.addAll(scmrk);           
           createGrass();
   
        }
        public void getAllGeneSelectedValues(List <String> scmrk,String type){       
           
            fetchedgenevalues.clear(); 
             regtextareacollections.clear(); 
           System.out.println("\n");
           selectedtype=type;
          // System.out.println("0th value:"+scmrk.get((0)));
            fetchedgenevalues.addAll(scmrk);           
           createGene();
   
        }
        
         public void getAllGeneSelectedValues2(List <String> scmrk,String type){       
           
            fetchedgenevalues.clear(); 
            regtextareacollections.clear(); 
            fetchedgenevalues.addAll(scmrk);
            selectedtype=type;
            //System.out.println(fetchedgenevalues.get(0)+"\n");
            createGene2();
   
        }
          
         
         private void createGene2(){
                 int x=80;
                 int y=10;
                 int y2=20;
                 content.getChildren().clear();
                 gridPane = new GridPane();
                 gridPane.setGridLinesVisible(true);
                 gridPane.setVisible(true);
                 gridPane.setLayoutX(300);
                 gridPane.setLayoutY(80);
                 
                 ColumnConstraints col1 = new ColumnConstraints();
                 col1.setPercentWidth(60);
                 col1.setHalignment(HPos.CENTER);
                 ColumnConstraints col2 = new ColumnConstraints();
                 col2.setPercentWidth(120);
                 col2.setHalignment(HPos.CENTER);
                 ColumnConstraints col3 = new ColumnConstraints();
                 col3.setPercentWidth(100);
                 col3.setHalignment(HPos.CENTER);
                 gridPane.getColumnConstraints().addAll(col1,col2,col3);
        
                 Label regionlabel =new Label("Region");
                 Label regionlabel2 =new Label("RK Non-Mutable");
                 Label regionlabel3 =new Label("RK Mutable");
                 //gridPane.setVgap(10);
                 //gridPane.setHgap(10);
                 gridPane.add(regionlabel,0,0);                 
                 gridPane.add(regionlabel2,1,0); 
                 gridPane.add(regionlabel3,2,0); 
                 
                     regline=new Line();
                     regline.setStartX(82.5);
                     regline.setStartY(25);                     
                     regline.setEndX(82.5);
                     regline.setEndY((fetchedgenevalues.size())*60-25);
                     content.getChildren().add(regline);
                     
                 
                   
        for(int i=0;i<fetchedgenevalues.size();i++){
            
                int v=i+1;
               reglabel=new Label();
               reglabel.setText("Reg"+v);  
              
               reglabel.setLayoutX(30);
               reglabel.setLayoutY(y);
                regrect=new Rectangle();
                regrect.setWidth(5);
               regrect.setHeight(25);
                regrect.setX(x);
                regrect.setY(y);
                  
                regtextarea =new TextArea();                 
                 regtextarea.setPrefHeight(10);  
                 regtextarea.setPrefWidth(90); 
                 regtextarea.setLayoutX(x+60);
                 regtextarea.setLayoutY(y-5);      
                   regline2=new Line();                    
                    regline2.setStartX(82.5);
                    regline2.setStartY(y2);                     
                     regline2.setEndX(140);
                   regline2.setEndY((y2));
                   
                     
                   String frmeq=fetchedgenevalues.get(i);
                   String[] parts = fetchedgenevalues.get(i).split("=", 2);
	                        if (parts.length >= 2)
	                        {
	                            String key = parts[0];
	                            String value = parts[1];
                                    key=key.replace("g_frm", "NE");
                                    regtextarea.setText(key);
                                }
                                regtextarea.setOnMouseClicked(e -> {
                    main.getselectedfrmeq(frmeq);
                    
                });
                                 int ref=i+1;
                                regchildlabel = new Label("Reg"+ref);
                                regchildlabel2=new Label("1");
                                regchildtext =new TextArea();
                               regchildtext.clear();
                                 regchildtext.setText("");
                                regchildtext.setEditable(false);
                                regchildtext.setPrefHeight(5);  
                                regchildtext.setPrefWidth(40);
                                regtextareacollections.add(regchildtext);
                                gridPane.add(regchildlabel, 0,ref);
                                gridPane.add(regchildlabel2,1,ref);
                               gridPane.add(regtextareacollections.get(i),2,ref);
                          
                               
                content.getChildren().add(regrect);
                content.getChildren().add(reglabel);
                content.getChildren().add(regtextarea);
                content.getChildren().add(regline2);
               
               
               
                // x=x+40;
                 y=y+60;
            y2=y2+60;
            
            
        }
                System.out.println("y value"+y);
                     regeditBtn.setLayoutX(400);
                     regeditBtn.setLayoutY((gridPane.getLayoutY()+20)+(45*fetchedgenevalues.size()));
                    //regeditBtn.setLayoutY(regtextareacollections.get(regtextareacollections.size()-1).getLayoutY());
                     regsubmitBtn.setLayoutX(500);
                     regsubmitBtn.setLayoutY((gridPane.getLayoutY()+20)+(45*fetchedgenevalues.size()));
              content.getChildren().addAll(gridPane); 
               content.getChildren().add(regeditBtn);
                content.getChildren().add(regsubmitBtn);
              content2.setContent(content);
              
              
              
                 regeditBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for(int j=0; j<regtextareacollections.size(); j++){
                regtextareacollections.get(j).setEditable(true);
               
               
            }
            }
        });
             regsubmitBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                 if(dynvaluefulleq2.isEmpty())
            {
            System.out.println("please upload file");
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Upload DYNAMIC VALUE FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();

            
        }
                 else{
                      
                     if(selectedtype.contains("ASXL")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn1() {");
                            int index2=dynvaluefulleq2.indexOf("void eval_dyn2() {");

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_ASXL1_mut ="+regtextareacollections.get(j).getText()+";";
                        text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_ASXL1");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
                           System.out.println("dum val"+dum.get(j));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                     
            }
                     if(selectedtype.contains("TP53")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn2() {");
                            int index2=dynvaluefulleq2.indexOf("void eval_dyn3() {");

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_TP53_mut = "+regtextareacollections.get(j).getText()+";";
                       text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_TP53");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
//                           System.out.println("dum val"+dum.get(j-1));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                      //regtextareacollections.clear();
            }
                     
                      if(selectedtype.contains("KRAS")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn3() {");
                           // int index2=dynvaluefulleq2.indexOf("void eval_dyn3() {");
                            int index2=dynvaluefulleq2.size()-1;

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_KRAS_mut = "+regtextareacollections.get(j).getText()+";";
                       text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_KRAS");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
//                           System.out.println("dum val"+dum.get(j-1));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                      //regtextareacollections.clear();
            }
                     
                      try{    
          FileWriter fw=new FileWriter(dynpath);              
          
          for(int i= 0; i< dynvaluefulleq2.size();i++){
                      
              fw.write(dynvaluefulleq2.get(i));
              fw.write("\n");
              
                      }
          
                                
                 
           fw.write("}");
           fw.close();
            
          }
               catch(Exception e){System.out.println(e);}
                     
                     
                     
                     
               //regtextareacollections.clear();  
                 }
            
            }
                
                 });
              
             
             
          }
       
     
        private void createGene(){
          
                 int x=80;
                 int y=10;
                 int y2=20;
                 content.getChildren().clear();
                 gridPane = new GridPane();
                 gridPane.setGridLinesVisible(true);
                 gridPane.setVisible(true);
                 gridPane.setLayoutX(300);
                 gridPane.setLayoutY(80);
                 
                 ColumnConstraints col1 = new ColumnConstraints();
                 col1.setPercentWidth(60);
                 col1.setHalignment(HPos.CENTER);
                 ColumnConstraints col2 = new ColumnConstraints();
                 col2.setPercentWidth(120);
                 col2.setHalignment(HPos.CENTER);
                 ColumnConstraints col3 = new ColumnConstraints();
                 col3.setPercentWidth(100);
                 col3.setHalignment(HPos.CENTER);
                 gridPane.getColumnConstraints().addAll(col1,col2,col3);
        
                 Label regionlabel =new Label("Region");
                 Label regionlabel2 =new Label("RK Non-Mutable");
                 Label regionlabel3 =new Label("RK Mutable");
                 //gridPane.setVgap(10);
                 //gridPane.setHgap(10);
                 gridPane.add(regionlabel,0,0);                 
                 gridPane.add(regionlabel2,1,0); 
                 gridPane.add(regionlabel3,2,0); 
                 
                     regline=new Line();
                     regline.setStartX(82.5);
                     regline.setStartY(25);                     
                     regline.setEndX(82.5);
                     regline.setEndY((fetchedgenevalues.size())*60-25);
                     content.getChildren().add(regline);
                     
                 
                   
        for(int i=0;i<fetchedgenevalues.size();i++){
            
                int v=i+1;
               reglabel=new Label();
               reglabel.setText("Reg"+v);  
              
               reglabel.setLayoutX(30);
               reglabel.setLayoutY(y);
                regrect=new Rectangle();
                regrect.setWidth(5);
               regrect.setHeight(25);
                regrect.setX(x);
                regrect.setY(y);
                  
                regtextarea =new TextArea();                 
                 regtextarea.setPrefHeight(10);  
                 regtextarea.setPrefWidth(90); 
                 regtextarea.setLayoutX(x+60);
                 regtextarea.setLayoutY(y-5);      
                   regline2=new Line();                    
                    regline2.setStartX(82.5);
                    regline2.setStartY(y2);                     
                     regline2.setEndX(140);
                   regline2.setEndY((y2));
                   
                     
                   String frmeq=fetchedgenevalues.get(i);
                   String[] parts = fetchedgenevalues.get(i).split("=", 2);
	                        if (parts.length >= 2)
	                        {
	                            String key = parts[0];
	                            String value = parts[1];
                                    key=key.replace("g_frm", "NE");
                                    regtextarea.setText(key);
                                }
                                regtextarea.setOnMouseClicked(e -> {
                    main.getselectedfrmeq(frmeq);
                    
                });
                                 int ref=i+1;
                                regchildlabel = new Label("Reg"+ref);
                                regchildlabel2=new Label("1");
                                regchildtext =new TextArea();
                               regchildtext.clear();
                                 regchildtext.setText("");
                                regchildtext.setEditable(false);
                                regchildtext.setPrefHeight(5);  
                                regchildtext.setPrefWidth(40);
                                regtextareacollections.add(regchildtext);
                                gridPane.add(regchildlabel, 0,ref);
                                gridPane.add(regchildlabel2,1,ref);
                               gridPane.add(regtextareacollections.get(i),2,ref);
                          
                               
                content.getChildren().add(regrect);
                content.getChildren().add(reglabel);
                content.getChildren().add(regtextarea);
                content.getChildren().add(regline2);
               
               
               
                // x=x+40;
                 y=y+60;
            y2=y2+60;
            
            
        }
                System.out.println("y value"+y);
                     regeditBtn.setLayoutX(400);
                     regeditBtn.setLayoutY((gridPane.getLayoutY()+20)+(45*fetchedgenevalues.size()));
                    //regeditBtn.setLayoutY(regtextareacollections.get(regtextareacollections.size()-1).getLayoutY());
                     regsubmitBtn.setLayoutX(500);
                     regsubmitBtn.setLayoutY((gridPane.getLayoutY()+20)+(45*fetchedgenevalues.size()));
              content.getChildren().addAll(gridPane); 
               content.getChildren().add(regeditBtn);
                content.getChildren().add(regsubmitBtn);
              content2.setContent(content);
              
              
              
                 regeditBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for(int j=0; j<regtextareacollections.size(); j++){
                regtextareacollections.get(j).setEditable(true);
               
               
            }
            }
        });
                  regsubmitBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                 if(dynvaluefulleq2.isEmpty())
            {
            System.out.println("please upload file");
            
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Upload DYNAMIC VALUE FILE");
            alert.setHeaderText("Please upload FRM File to check NODE");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show();

            
        }
                 else{
                      
                     if(selectedtype.equals("ASXL")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn1() {");
                            int index2=dynvaluefulleq2.indexOf("void eval_dyn2() {");

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_ASXL1_mut ="+regtextareacollections.get(j).getText()+";";
                        text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_ASXL1");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
                           System.out.println("dum val"+dum.get(j));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                     
            }
                     if(selectedtype.equals("TP53")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn2() {");
                            int index2=dynvaluefulleq2.indexOf("void eval_dyn3() {");

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_TP53_mut = "+regtextareacollections.get(j).getText()+";";
                       text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_TP53");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
//                           System.out.println("dum val"+dum.get(j-1));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                      //regtextareacollections.clear();
            }
                     
                      if(selectedtype.equals("KRAS")){
                         List<String> dum= new ArrayList<String>();
                            gettextareavalue.clear();
                            int index=dynvaluefulleq2.indexOf("void eval_dyn3() {");
                           // int index2=dynvaluefulleq2.indexOf("void eval_dyn3() {");
                            int index2=dynvaluefulleq2.size()-1;

                     for(int j=0; j<regtextareacollections.size();j++){
                         int k=j+1;
                       
                       if(!regtextareacollections.get(j).getText().equals("")){
                        String text="	Rk_"+k+"_KRAS_mut = "+regtextareacollections.get(j).getText()+";";
                       text=text.replace("[", "\\[").replace("]", "\\]").replace("]_", "\\_");
                         gettextareavalue.add(text);
                         dum.add("Rk_"+k+"_KRAS");
                        System.out.println(text);
                        System.out.println("Rk_"+j);
                     }}
                      for(int i=index; i<index2;i++){
                          System.out.println("sdaklfknjji"+dynvaluefulleq2.get(i));
                             String oh=dynvaluefulleq2.get(i);
                             //oh=oh.replace("[", "\\[").replace("]", "\\]").replace("_", "\\_");
                              System.out.println("oh value"+oh);
                          for(int j=0; j<dum.size();j++){
                              String oh2=dum.get(j);
//                           System.out.println("dum val"+dum.get(j-1));
                      if(oh.contains(oh2)){
                          
                          dynvaluefulleq2.set(i, gettextareavalue.get(j));
                          System.out.println("aftet"+dynvaluefulleq2.get(i));
                      }
                     }
                      }
                      //regtextareacollections.clear();
            }
                     
                      try{    
          FileWriter fw=new FileWriter(dynpath);              
          
          for(int i= 0; i< dynvaluefulleq2.size();i++){
                      
              fw.write(dynvaluefulleq2.get(i));
              fw.write("\n");
              
                      }
          
                                
                 
           fw.write("}");
           fw.close();
            
          }
               catch(Exception e){System.out.println(e);}
                     
                     
                     
                     
               //regtextareacollections.clear();  
                 }
            
            }
                
                 });
              
              
              
              
              
              
            }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
         private void createGrass(){
          
              int x=80;
            int y=10;
            int y2=20;
            content.getChildren().clear();
            
            if(fetchedscmvalues.get(0).equals("no values detected")){
                
                nodata.setText("No Nodes Found");
                nodata.setLayoutX(250);
                nodata.setLayoutY(250);
                content.getChildren().add(nodata);
                gridPane.setVisible(false);
            }
            else{
                 gridPane = new GridPane();
                 gridPane.setGridLinesVisible(true);
                 gridPane.setVisible(true);
                 gridPane.setLayoutX(300);
                 gridPane.setLayoutY(80);
                 
                 ColumnConstraints col1 = new ColumnConstraints();
                 col1.setPercentWidth(60);
                 col1.setHalignment(HPos.CENTER);
                 ColumnConstraints col2 = new ColumnConstraints();
                 col2.setPercentWidth(120);
                 col2.setHalignment(HPos.CENTER);
                 ColumnConstraints col3 = new ColumnConstraints();
                 col3.setPercentWidth(100);
                 col3.setHalignment(HPos.CENTER);
                 gridPane.getColumnConstraints().addAll(col1,col2,col3);
        
                 Label regionlabel =new Label("Region");
                 Label regionlabel2 =new Label("RK Non-Mutable");
                 Label regionlabel3 =new Label("RK Mutable");
                 //gridPane.setVgap(10);
                 //gridPane.setHgap(10);
                 gridPane.add(regionlabel,0,0);                 
                 gridPane.add(regionlabel2,1,0); 
                 gridPane.add(regionlabel3,2,0); 
                 
                     regline=new Line();
                     regline.setStartX(82.5);
                     regline.setStartY(25);                     
                     regline.setEndX(82.5);
                     regline.setEndY((fetchedscmvalues.size())*60-25);
                     content.getChildren().add(regline);
                     regeditBtn.setLayoutX(450);
                     regeditBtn.setLayoutY(500);
                     regsubmitBtn.setLayoutX(500);
                     regsubmitBtn.setLayoutY(500);
                 
                   
        for(int i=0;i<fetchedscmvalues.size();i++){
            
                int v=i+1;
               reglabel=new Label();
               reglabel.setText("Reg"+v);  
              
               reglabel.setLayoutX(30);
               reglabel.setLayoutY(y);
                regrect=new Rectangle();
                regrect.setWidth(5);
               regrect.setHeight(25);
                regrect.setX(x);
                regrect.setY(y);
                  
                regtextarea =new TextArea();                 
                 regtextarea.setPrefHeight(10);  
                 regtextarea.setPrefWidth(90); 
                 regtextarea.setLayoutX(x+60);
                 regtextarea.setLayoutY(y-5);      
                   regline2=new Line();                    
                    regline2.setStartX(82.5);
                    regline2.setStartY(y2);                     
                     regline2.setEndX(140);
                   regline2.setEndY((y2));
                   
                     
                   
                   String[] parts = fetchedscmvalues.get(i).split("=", 2);
	                        if (parts.length >= 2)
	                        {
	                            String key = parts[0];
	                            String value = parts[1];
                                    key=key.replace("g_frm", "NE");
                                    regtextarea.setText(key);
                                }
                                 int ref=i+1;
                                regchildlabel = new Label("Reg"+ref);
                                regchildlabel2=new Label("1");
                                regchildtext =new TextArea();
                                regchildtext.setEditable(false);
                                regchildtext.setPrefHeight(5);  
                                regchildtext.setPrefWidth(40);
                                regtextareacollections.add(regchildtext);
                                gridPane.add(regchildlabel, 0,ref);
                                gridPane.add(regchildlabel2,1,ref);
                               gridPane.add(regtextareacollections.get(i),2,ref);
                          
                content.getChildren().add(regrect);
                content.getChildren().add(reglabel);
                content.getChildren().add(regtextarea);
                content.getChildren().add(regline2);
               
               
               
                // x=x+40;
                 y=y+60;
            y2=y2+60;
            
        }
              
                 regeditBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                for(int j=0; j<regtextareacollections.size(); j++){
                regtextareacollections.get(j).setEditable(true);
               
               
            }
            }
        });
                  
                 regsubmitBtn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
               values();
             // getAllDynValues();
                FileChooser fileChooser = new FileChooser();
              
            //Set extension filter
            FileChooser.ExtensionFilter extFilter = 
                new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
            fileChooser.getExtensionFilters().add(extFilter);
             
            //Show save file dialog
            File file = fileChooser.showSaveDialog(new Stage());
             
            if(file != null){
               
            }
               try{    
           FileWriter fw=new FileWriter(file);              
          for(int i=0;i<dynvaluefulleq3.size();i++)
          {
           fw.write(dynvaluefulleq3.get(i));  
           //System.out.println("LINESSSSSS...:"+dynvaluefulleq3);
           fw.write("\n");
         }
          fw.write("void eval_dynEditValue() {");
          fw.write("\n");
          for(int j=0; j<regtextareacollections.size();j++){
                 gettextareavalue.clear();
                 gettextareavalue.add(regtextareacollections.get(j).getText());                
         // System.out.println("textxxxx"+gettextareavalue);
          for(int z=0; z<gettextareavalue.size();z++){
             // int S=1;
              //S++;
              //System.out.println("ZZZZ"+S++);
              fw.write("\t Rk_"+z+1+"="+gettextareavalue.get(z).toString());
              fw.write("\n");
            
          }
                                
                 }
           fw.write("}");
           fw.close();
            
          }
               catch(Exception e){System.out.println(e);}    
          System.out.println("File Created Success..."); 
}   
                 });
                
            }     
              content.getChildren().addAll(gridPane); 
               content.getChildren().add(regeditBtn);
                content.getChildren().add(regsubmitBtn);
              
            }

	public void init(MainController mainController) {
		main = mainController;
	}

   public void getAllDynValues(List<String> value) {
        //dynvaluefulleq2.clear();
       dynvaluefulleq2.addAll(value);
     //System.out.println("Values::"+dynvaluefulleq2);
     
      
    }
 public void getdynpath(String path) {
        //dynvaluefulleq2.clear();
       dynpath=path;
     //System.out.println("Values::"+dynvaluefulleq2);
     
      
    }

    private void values() {
for(int j=0; j<dynvaluefulleq2.size(); j++){
       // System.out.println("//Values::"+dynvaluefulleq2.get(j).toString());
      dynvaluefulleq3.add(dynvaluefulleq2.get(j).toString());
     // System.out.println("//Values:://"+dynvaluefulleq2.get(j).toString());
       }    
    }

    }

    

