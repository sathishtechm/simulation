/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tab;

import controller.MainController;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

/**
 *
 * @author SB00519010
 */
public class Tab6Controller {
     private MainController main;
     @FXML
     private ComboBox species;
     @FXML
     private ComboBox reaction;
     @FXML
     private ComboBox parameter;
     @FXML
     private Button mdsl;
     public String path;
    @FXML
     List<String>  speciesvalues2=new ArrayList<String>(); 
    @FXML
     List<String>  reactionvalues2 =new ArrayList<String>(); 
    @FXML
     List<String>  parametervalues2 =new ArrayList<String>(); 

    public void init(MainController mainController) {
		main = mainController;
	}
    
    public void setMDSL(List<String> speciesvalues,List <String> reactionvalues ,List<String> parametervalues,String mdslpath){             
         
         
        //speciesvalues.addAll(speciesvalues);
        //reactionvalues.addAll(reactionvalues);
        //parametervalues.addAll(parametervalues);
        
        species.getItems().addAll(speciesvalues);
        speciesvalues2.addAll(speciesvalues);
        reactionvalues2.addAll(reactionvalues);
        parametervalues2.addAll(parametervalues);
        
        reaction.getItems().addAll(reactionvalues);
        parameter.getItems().addAll(parametervalues);
        path=mdslpath;
        
        
        }
    
    @FXML private void speciesclick(ActionEvent event) {
   
   }
    @FXML private void reactionclick(ActionEvent event) {
   
   }
     @FXML private void parameterclick(ActionEvent event) {
   
   }
      @FXML private void mdslbtn(ActionEvent event) {
   try{    
            FileWriter fw=new FileWriter(path+"/new_eval_dyn.txt"); 
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("PATH");
            alert.setHeaderText(path+"/new_eval_dyn.txt");
            //String s ="Please upload FRM File to check NODE";
            //alert.setContentText(s);
            alert.show(); 
          //FileWriter fw=new FileWriter(path+"/Convert_method_on_MDSL.g_to_eval_dyn.txt");              
          fw.write(" // Species redefinition");
          fw.write("\n");
          fw.write("\n");
          for(int i= 0; i< speciesvalues2.size();i++){
                      
              fw.write(speciesvalues2.get(i)+";");
              
              fw.write("\n");
              
              
                      }
          fw.write("\n");
           fw.write(" // Reaction redefinition");
          fw.write("\n");
          for(int i= 0; i< reactionvalues2.size();i++){
                      
              fw.write(reactionvalues2.get(i)+";");
              
              fw.write("\n");
              
                      }
          fw.write("\n");
          
           fw.write(" // Parameter redefinition");
          fw.write("\n");
          for(int i= 0; i< parametervalues2.size();i++){
                      
              fw.write(parametervalues2.get(i)+";");
              
              fw.write("\n");
              
                      }
          
          
                                
                 
           
           fw.close();
            
          }
               catch(Exception e){System.out.println(e);}
   }
    
}
