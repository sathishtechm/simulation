package controller;

import javafx.fxml.FXML;
import controller.tab.Tab1Controller;
import controller.tab.Tab2Controller;
import controller.tab.Tab3Controller;
import controller.tab.Tab4Controller;
import controller.tab.Tab5Controller;
import controller.tab.Tab6Controller;

import java.io.File;
import java.util.List;
import javafx.scene.control.TabPane;

public class MainController {
	@FXML Tab1Controller tab1Controller;
	@FXML Tab2Controller tab2Controller;
        @FXML Tab3Controller tab3Controller;
        @FXML Tab4Controller tab4Controller;
        @FXML Tab5Controller tab5Controller;
        @FXML Tab6Controller tab6Controller;
     
        
        @FXML private TabPane  tabpane;
        
        
       
	
	@FXML public void initialize() {
		System.out.println("Application started");
		tab1Controller.init(this);
		tab2Controller.init(this);
                tab3Controller.init(this);
                tab4Controller.init(this);
                tab5Controller.init(this);
                tab6Controller.init(this);
               
              
	}

	public void getAllScmSelectedValues(List <String> scmrk){
            //System.out.println("testing..."+scmrk.get(0));
          tabpane.getSelectionModel().select(0);
          tab1Controller.getAllScmSelectedValues(scmrk);
        }
      public void getAllIcmSelectedValues(List <String> scmrk1){
           //System.out.println("testing..."+scmrk1.get(0));
          tabpane.getSelectionModel().select(1);
         //tab2Controller.getAllIcmSelectedValues(scmrk1);
        }
      public void getAllGeneValues(List <String> gene,String type){
           //System.out.println("testing..."+scmrk1.get(0));
          tabpane.getSelectionModel().select(0);
          tab1Controller.getAllGeneSelectedValues(gene,type);
         //tab2Controller.getAllIcmSelectedValues(scmrk1);
        }
      public void getAllGeneValues2(List <String> gene,String type){
           //System.out.println("testing..."+scmrk1.get(0));
          tabpane.getSelectionModel().select(0);
          tab1Controller.getAllGeneSelectedValues2(gene,type);
         //tab2Controller.getAllIcmSelectedValues(scmrk1);
        }
	
        public void setFilePath(List<File> file){
            //System.out.println(file.get(0).getPath());
            tab3Controller.getFilePath(file);
            
        }
          public void setAllDynValues(List<String> value){             
         tab1Controller.getAllDynValues(value);
//         System.out.println("VALUESS!!!::"+value.get(0));
          }
          public void setdynpath(String path){             
         tab1Controller.getdynpath(path);
         System.out.println("path main"+path);
         
          }
          public void getselectedfrmeq(String frmeq){             
         tab5Controller.setselectedfrmeq(frmeq);
         
          }
          public void setMDSL(List<String> speciesvalues,List <String> reactionvalues ,List<String> parametervalues,String mdslpath){             
          tab6Controller.setMDSL(speciesvalues,reactionvalues,parametervalues,mdslpath);
          tab1Controller.setMDSL(speciesvalues,reactionvalues,parametervalues,mdslpath);
          
         
          }
          public void setMDSL2(List <String> parametervalues){             
          tab1Controller.getRKvalues(parametervalues);
         
          }
          
          
         
        
     //   public void sendFilePath(){
          // tab3Controller.getFilePath(file);
        //}
}
