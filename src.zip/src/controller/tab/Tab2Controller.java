package controller.tab;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import controller.MainController;
import java.util.List;
import javafx.scene.control.TabPane;

public class Tab2Controller {
	
	private MainController main;
	 @FXML private TabPane  tabpane;
	

	public void init(MainController mainController) {
		main = mainController;
	}

    public void getAllIcmSelectedValues(List<String> scmrk1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
